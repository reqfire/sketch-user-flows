var that = this;
function __skpm_run (key, context) {
  that.context = context;

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

Object.defineProperty(exports, "__esModule", {
    value: true
});

exports["default"] = function (context) {
    // always reload script before running
    coscript.setShouldKeepAround(false);
    var sketch = context.api();
    var app = NSApplication.sharedApplication();
    var document = sketch.selectedDocument;
    var page = document.selectedPage;
    var pages = context.document.pages();
    var imageUrl = "https://www.reqfire.com/app/images/";
    var jsonUrl = "https://www.reqfire.com/app/project/sketchexport/";

    //text colors
    var subtitleColor = MSColor.colorWithRed_green_blue_alpha(0.8, 0.8, 0.8, 1);
    var groupColor = MSColor.colorWithRed_green_blue_alpha(0.6078431373, 0.6078431373, 0.6078431373, 1);
    var flowColor = MSColor.colorWithRed_green_blue_alpha(0.2588235294, 0.2588235294, 0.2588235294, 1);
    var versionColor = MSColor.colorWithRed_green_blue_alpha(0, 0, 0, 0.34);
    var hintColor = MSColor.colorWithRed_green_blue_alpha(0.8156862745, 0.007843137255, 0.1058823529, 1);

    var jsonInput;
    // get file path
    var manifestPath = context.plugin.url().URLByAppendingPathComponent("Contents").URLByAppendingPathComponent("Sketch").URLByAppendingPathComponent("manifest.json").path();
    // read the .json file content
    var manifest = NSJSONSerialization.JSONObjectWithData_options_error(NSData.dataWithContentsOfFile(manifestPath), 0, nil);
    var version = manifest.version;

    // default page name when open a new file
    var defaultPage = "Page 1";

    // uesr input project api key
    if (getInputFromUser(context)) {
        logRequest(jsonInput);

        // get json object
        var obj = getJSONFromURL(jsonUrl, jsonInput);

        //get all symbols (interfaces) in current project
        var symbolList = getSymbols(context, pages);

        if (obj) {
            // current version is the latest
            if (version == obj.version) {
                // convert json object
                obj = convertData(obj);

                // opened file has no symbol page or no symbol
                if (!symbolList) {
                    // create groups for ifaces
                    for (var i = 0; i < obj.ifaces.length; i++) {
                        var iName = obj.ifaces[i].name;
                        var iPid = obj.ifaces[i].persistent_id;
                        var iUrl = imageUrl + obj.ifaces[i].image;
                        // create layers for all ifaces in the project  
                        createGroup(iName + " id:" + iPid, iUrl);
                    }

                    // get current page after create all the iface layers 
                    var currentPage = context.document.currentPage();
                    var number = currentPage.layers().length;
                    var layer;

                    // create symbol for each layer (group)
                    for (var i = 0; i < number; i++) {
                        layer = currentPage.layers()[i];
                        var layerArray = MSLayerArray.arrayWithLayers([layer]);
                        var symbolName = currentPage.layers()[i].name();
                        // create symbol for each layer in the document and send symbols to "Symbol" Page 
                        MSSymbolCreator.createSymbolFromLayers_withName_onSymbolsPage(layerArray, symbolName, true);
                    }
                } else {
                    // there are symbols exist already
                    // create a temporary page to save the layers created for ifaces exist in reqfire project but not on current sketch file
                    var tempPage = context.document.documentData().addBlankPage();
                    tempPage.setName("reqfire_temp");
                    var flag;

                    // compare exist symbol's ID with ifaces persistent_id in json object
                    for (var i = 0; i < obj.ifaces.length; i++) {
                        for (var j = 0; j < symbolList.length; j++) {
                            var X = symbolList[j].name();
                            var ID = X.split(" id:")[1];

                            if (obj.ifaces[i].persistent_id == ID) {
                                flag = 1; // iface exist in sketch file
                                break;
                            } else {
                                flag = -1;
                            }
                        }

                        if (flag == 1) {
                            // iface exist in sketch file
                            // update the symbol's name only
                            updateSymbol(obj.ifaces[i].persistent_id, obj.ifaces[i].name + " id:" + obj.ifaces[i].persistent_id);
                        } else {
                            // create new layers for ifaces do not exist in sketch file
                            var iName = obj.ifaces[i].name;
                            var iUrl = imageUrl + obj.ifaces[i].image;
                            page = document.selectedPage; // update the value of current selected page (reqfire_temp)
                            createGroup(iName + " id:" + obj.ifaces[i].persistent_id, iUrl);
                        }
                    }

                    var number = tempPage.layers().length;
                    var layer;

                    // create symbol for each layer
                    for (var i = 0; i < number; i++) {
                        layer = tempPage.layers()[i];
                        var layerArray = MSLayerArray.arrayWithLayers([layer]);
                        var symbolName = tempPage.layers()[i].name();
                        MSSymbolCreator.createSymbolFromLayers_withName_onSymbolsPage(layerArray, symbolName, true);
                    }
                }

                removePage("reqfire_temp");
                removePage("User Flows");
                removePage("Welcome");
                removePage(defaultPage);

                // create a new page to save user flows of the project
                var goalPage = context.document.documentData().addBlankPage();
                goalPage.setName("User Flows");
                createArtboard(goalPage, obj); // create texts and artboards to illustrate all the user flows
                organizeSymbol(obj); // clean the Symbol page by deleting blank shape
                createInfoPage(context);
            } else {
                app.displayDialog_withTitle("You can install the latest version from plugin manage in Sketch", "Invalid Version");
            }
        } else {
            app.displayDialog_withTitle("Could not find the project with the apikey", "No project Found");
        }
    } else {
        log("no");
    }

    // create a rectangle shape with image fill 
    function createGroup(name, url) {
        var FillType = { Solid: 0, Gradient: 1, Pattern: 4, Noise: 5 };
        var PatternFillType = { Tile: 0, Fill: 1, Stretch: 2, Fit: 3 };
        var groupShape = page.newShape({
            frame: new sketch.Rectangle(200, 200, 1440, 1024),
            name: name
        });

        // convert shape into a sketch object to enable setting its style
        var group = groupShape.sketchObject;
        //set shape fills 
        var fill = group.style().addStylePartOfType(0);
        var image = fetchImage(url);

        if (image) {
            fill.fillType = FillType.Pattern;
            fill.patternFillType = PatternFillType.Fit;
            fill.image = MSImageData.alloc().initWithImage(image);
        } else {
            print("Can't load image!");
        }

        // set shape boarder color
        var border = group.style().addStylePartOfType(1);
        border.color = MSImmutableColor.colorWithSVGString("black");
    }

    //delete the shape with no fill image on symbol page
    function organizeSymbol(obj) {
        var symbolMasters = context.document.documentData().allSymbols(); // get all symbols in document

        obj.ifaces.forEach(function (iface) {
            if (iface.image == "null") {
                // if the iface has no image in reqfire project
                symbolMasters.forEach(function (symbolMaster) {
                    // search for the corresponding symbol
                    if (symbolMaster.name() == iface.name + " id:" + iface.persistent_id) {
                        symbolMaster.children()[0].removeFromParent(); // remove the symbol's child element (a shape with no image fill)
                    }
                });
            }
        });
    }

    // create artboard based on groups and use cases
    function createArtboard(page, object) {
        var setY = 0;

        for (var i = 0; i < object.groups.length; i++) {
            var groupName = object.groups[i].name;

            // Group Name Label
            var subtitle = MSTextLayer["new"]();
            subtitle.setName("Group Name");
            subtitle.setStringValue("Group Name");
            subtitle.setFontPostscriptName("Helvetica");
            subtitle.setFontSize(24);
            subtitle.setTextAlignment(0);
            subtitle.setTextColor(subtitleColor);
            var tFrame = subtitle.frame();
            tFrame.setX(0);
            tFrame.setY(setY);
            page.addLayer(subtitle);

            // Group Name Heading
            var text = MSTextLayer["new"]();
            text.setName(groupName);
            text.setStringValue(groupName);
            text.setFontPostscriptName("Helvetica-Bold");
            text.setFontSize(64);
            text.setTextAlignment(0);
            text.setTextColor(groupColor);
            var tFrame = text.frame();
            tFrame.setX(-3);
            tFrame.setY(setY + 29);
            page.addLayer(text);

            if (object.groups[i].uc) {
                for (var n = 0; n < object.groups[i].uc.length; n++) {
                    var useCaseName = object.groups[i].uc[n].name;
                    var flowNo = object.groups[i].uc[n].flow.length;
                    for (var j = 0; j < flowNo; j++) {
                        if (object.groups[i].uc[n].flow[j].step) {
                            var interfaceNo = object.groups[i].uc[n].flow[j].step.length;

                            // Flow Name Label

                            // Flow Name Heading
                            var flowHeading = MSTextLayer["new"]();
                            flowHeading.setName(useCaseName);
                            flowHeading.setStringValue(useCaseName);
                            flowHeading.setFontPostscriptName("Helvetica-Bold");
                            flowHeading.setFontSize(36);
                            flowHeading.setTextAlignment(0);
                            flowHeading.setTextColor(flowColor);
                            var tFrame = flowHeading.frame();
                            tFrame.setX(70);
                            tFrame.setY(setY + 29 + 77 + 48); // setY + gap to group heading + group heading height + gap to flow heading
                            page.addLayer(flowHeading);

                            for (var k = 0; k < interfaceNo; k++) {
                                if (object.groups[i].uc[n].flow[j].step[k].object) {
                                    var interfaceName = object.groups[i].uc[n].flow[j].step[k].object.name;
                                    var interfacePid = object.groups[i].uc[n].flow[j].step[k].object.persistent_id;

                                    var artboardName = interfaceName;
                                    var artboard = MSArtboardGroup["new"]();
                                    artboard.setName(String.fromCharCode("a".charCodeAt() + k) + ". " + artboardName);
                                    var frame = artboard.frame();
                                    frame.setX(70 + 1540 * k); // offset + (artboard with + gap) * k
                                    frame.setY(setY + 29 + 77 + 48 + 43 + 50); // setY + gap to group heading + group heading height + gap to flow heading + flow heading height + gap to board
                                    frame.setWidth(1440);
                                    frame.setHeight(1024);
                                    var insertSymbol = symbolMasterWithName( // find the symbol by name that needs to create an instance 
                                    context, interfaceName + " id:" + interfacePid);
                                    var symbolInstance = insertSymbol.newSymbolInstance(); // create an symbol instance
                                    page.addLayer(artboard);
                                    artboard.addLayer(symbolInstance);
                                } else {
                                    var blankText = MSTextLayer["new"]();
                                    blankText.setName("Text");
                                    blankText.setStringValue("No interface linked");
                                    blankText.setFontPostscriptName("Helvetica-Bold");
                                    blankText.setFontSize(64);
                                    blankText.setTextAlignment(1);
                                    var tFrame = blankText.frame();
                                    tFrame.setX(70 + 1540 * k + 1440 / 2 - 573 / 2);
                                    tFrame.setY(setY + 29 + 77 + 48 + 43 + 50 + 1024 / 2 - 77 / 2);
                                    page.addLayer(blankText);
                                }
                            }
                        } else {
                            // user goal has no step
                            var flowHeading = MSTextLayer["new"]();
                            flowHeading.setName(useCaseName + " has no steps");
                            flowHeading.setStringValue(useCaseName + " has no steps");
                            flowHeading.setFontPostscriptName("Helvetica-Bold");
                            flowHeading.setFontSize(36);
                            flowHeading.setTextAlignment(0);
                            flowHeading.setTextColor(flowColor);
                            var tFrame = flowHeading.frame();
                            tFrame.setX(70);
                            tFrame.setY(setY + 29 + 77 + 48); // setY + gap to group heading + group heading height + gap to flow heading
                            page.addLayer(flowHeading);
                        }
                    }
                    setY = setY + 29 + 77 + 48 + 43 + 50 + 1024 + 100;
                }
            } else {
                // group has no use flows
                var message = MSTextLayer["new"]();
                message.setName(groupName + "has no Flows");
                message.setStringValue(groupName + " has no Flows");
                message.setFontPostscriptName("Helvetica-Bold");
                message.setFontSize(36);
                message.setTextAlignment(0);
                message.setTextColor(flowColor);
                var tFrame = message.frame();
                tFrame.setX(70);
                tFrame.setY(setY + 29 + 77 + 48);
                page.addLayer(message);

                setY = setY + 29 + 77 + 48 + 43 + 50 + 1024 + 100;
            }
        }
    }

    //return symbol by name
    function symbolMasterWithName(context, name) {
        var loopSymbolMasters = context.document.documentData().allSymbols().objectEnumerator();
        var symbolMaster;

        while (symbolMaster = loopSymbolMasters.nextObject()) {
            // loop all the symbols
            if (symbolMaster.name().isEqualToString(name)) {
                return symbolMaster;
            }
        }
    }

    //update symbol
    function updateSymbol(id, name) {
        var loopSymbolMasters = context.document.documentData().allSymbols().objectEnumerator();
        var symbolMaster;

        while (symbolMaster = loopSymbolMasters.nextObject()) {
            if (symbolMaster.name().split(" id:")[1] == id) {
                symbolMaster.setName(name); // only update symbol name
            }
        }
    }

    //retrive image data from url
    function fetchImage(url, ingnoreCache) {
        var request = ingnoreCache ? NSURLRequest.requestWithURL_cachePolicy_timeoutInterval(NSURL.URLWithString(url), NSURLRequestReloadIgnoringLocalCacheData, 60) : NSURLRequest.requestWithURL(NSURL.URLWithString(url));

        var responsePtr = MOPointer.alloc().init();
        var errorPtr = MOPointer.alloc().init();
        var data = NSURLConnection.sendSynchronousRequest_returningResponse_error(request, responsePtr, errorPtr);

        if (errorPtr.value() != null) {
            return null;
        }

        var response = responsePtr.value();

        if (response.statusCode() != 200) {
            return null;
        }

        var mimeType = response.allHeaderFields()["Content-Type"];

        if (!mimeType || !mimeType.hasPrefix("image/")) {
            return null;
        }

        return NSImage.alloc().initWithData(data);
    }

    // make request to get object data from json url
    function getJSONFromURL(url, key) {
        var task = NSTask.alloc().init();
        task.setLaunchPath("/usr/bin/curl");

        var args = NSMutableArray.alloc().init();
        args.addObject("-v");
        args.addObject("POST");
        args.addObject("-F");
        args.addObject("apikey=" + key);
        args.addObject(url);
        task.setArguments(args);

        var outputPipe = NSPipe.pipe();
        task.setStandardOutput(outputPipe);
        task.launch();

        var outputData = outputPipe.fileHandleForReading();
        var data = outputData.readDataToEndOfFile();
        var classNameOfOutput = NSStringFromClass(data["class"]());

        if (classNameOfOutput != "_NSZeroData") {
            var res = NSJSONSerialization.JSONObjectWithData_options_error(data, NSJSONReadingMutableContainers, null);

            if (res != null) {
                if (res.status == 1) {
                    //success
                    log(res.content);
                    return res.content;
                } else {
                    return null;
                }
            }
        } else {
            return null;
        }
    }

    // flatten object
    function convertData(object) {
        var flattenByKey = function () {
            function flattenByKey(object, property) {
                return Object.keys(object[property]).map(function (key) {
                    return object[property][key];
                });
            }

            return flattenByKey;
        }();

        data = {};
        data.ifaces = object.ifaces;
        data.groups = flattenByKey(object, "groups");

        data.groups.forEach(function (group) {
            if (group.uc) {
                group.uc = flattenByKey(group, "uc");
                group.uc.forEach(function (uc) {
                    uc.flow = flattenByKey(uc, "flow");
                    uc.flow.forEach(function (flow) {
                        if (flow.step) {
                            flow.step = flattenByKey(flow, "step");
                            flow.step.forEach(function (step) {
                                if (step.object) {
                                    step.object = flattenByKey(step, "object");
                                    step.object = step.object.find(function (obj) {
                                        return obj.object_type == "12";
                                    });
                                }
                            });
                        }
                    });
                });
            }
        });

        return data;
    }

    // remove unused page by name
    function removePage(pageName) {
        var pages = context.document.pages();
        for (var i = 0; i < pages.count(); i++) {
            var page = pages[i];
            var name = page.name();
            if (name == pageName) {
                context.document.documentData().removePage(page);
                context.document.pageTreeLayoutDidChange(); //update the page tree
            }
        }
    }

    // get all the symbols on Symbols page
    function getSymbols(context, pages) {
        for (i = 0; i < pages.count(); i++) {
            if (pages[i].name().isEqualToString("Symbols")) {
                var layers = pages[i].layers();
                return layers;
            }
        }
    }

    //create Info Page
    function createInfoPage(context) {
        var infoPage = context.document.documentData().addBlankPage();
        infoPage.setName("Welcome");
        var page = document.selectedPage;

        var currentPage = context.document.currentPage();

        var welcome_artboard = MSArtboardGroup["new"]();
        welcome_artboard.setName("Welcome");
        var frame = welcome_artboard.frame();
        frame.setX(0);
        frame.setY(0);
        frame.setWidth(3730);
        frame.setHeight(2060);
        currentPage.addLayer(welcome_artboard);

        // Reqfire
        var welcome_heading_1 = MSTextLayer["new"]();
        welcome_heading_1.setName("User Flows");
        welcome_heading_1.setStringValue("User Flows");
        welcome_heading_1.setFontPostscriptName("Helvetica-Bold");
        welcome_heading_1.setFontSize(144);
        welcome_heading_1.setTextAlignment(0);
        welcome_heading_1.setTextColor(flowColor);
        var tFrame = welcome_heading_1.frame();
        tFrame.setX(192);
        tFrame.setY(300);
        welcome_artboard.addLayer(welcome_heading_1);

        // Sketch Plugin
        var welcome_heading_2 = MSTextLayer["new"]();
        welcome_heading_2.setName("Sketch plugin");
        welcome_heading_2.setStringValue("Sketch plugin");
        welcome_heading_2.setFontPostscriptName("Helvetica");
        welcome_heading_2.setFontSize(144);
        welcome_heading_2.setTextAlignment(0);
        welcome_heading_2.setTextColor(flowColor);
        var tFrame = welcome_heading_2.frame();
        tFrame.setX(192);
        tFrame.setY(450);
        welcome_artboard.addLayer(welcome_heading_2);

        // version
        var version = MSTextLayer["new"]();
        version.setName("Version");
        version.setStringValue("1.0.0");
        version.setFontPostscriptName("Helvetica Neue-Light");
        version.setFontSize(36);
        version.setTextAlignment(0);
        version.setTextColor(versionColor);
        var tFrame = version.frame();
        tFrame.setX(202);
        tFrame.setY(630);
        welcome_artboard.addLayer(version);

        // description_1
        var welcome_description_1 = MSTextLayer["new"]();
        welcome_description_1.setName("Description_1");
        welcome_description_1.setStringValue("A Sketch plug-in for importing/exporting user flows and interfaces from Reqfire.");
        welcome_description_1.setFontPostscriptName("Helvetica");
        welcome_description_1.setFontSize(36);
        welcome_description_1.setTextAlignment(0);
        welcome_description_1.setTextColor(flowColor);
        welcome_description_1.setTextBehaviour(1); // text is "fixed"
        var tFrame = welcome_description_1.frame();
        tFrame.setX(200);
        tFrame.setY(738);
        tFrame.setHeight(86);
        tFrame.setWidth(1000);
        welcome_artboard.addLayer(welcome_description_1);

        // description_2
        var welcome_description_2 = MSTextLayer["new"]();
        welcome_description_2.setName("Description_2");
        welcome_description_2.setStringValue("User Flows allows the importing of interfaces from Reqfire into a Sketch project, along with the defined Reqfire user flows.");
        welcome_description_2.setFontPostscriptName("Helvetica");
        welcome_description_2.setFontSize(36);
        welcome_description_2.setTextAlignment(0);
        welcome_description_2.setTextColor(flowColor);
        welcome_description_2.setTextBehaviour(1);
        var tFrame = welcome_description_2.frame();
        tFrame.setX(200);
        tFrame.setY(864);
        tFrame.setHeight(86);
        tFrame.setWidth(1000);
        welcome_artboard.addLayer(welcome_description_2);

        // description_3
        var welcome_description_3 = MSTextLayer["new"]();
        welcome_description_3.setName("Description_3");
        welcome_description_3.setStringValue("Interfaces can be designed in Sketch and then exported back to Reqfire as .png files to be included in the Reqfire project.");
        welcome_description_3.setFontPostscriptName("Helvetica");
        welcome_description_3.setFontSize(36);
        welcome_description_3.setTextAlignment(0);
        welcome_description_3.setTextColor(flowColor);
        welcome_description_3.setTextBehaviour(1);
        var tFrame = welcome_description_3.frame();
        tFrame.setX(200);
        tFrame.setY(990);
        tFrame.setHeight(86);
        tFrame.setWidth(1000);
        welcome_artboard.addLayer(welcome_description_3);

        // description_4
        var welcome_description_4 = MSTextLayer["new"]();
        welcome_description_4.setName("Description_4");
        welcome_description_4.setStringValue("Subsequent import operations to the same Sketch project will not overwrite existing work, but will add any newly created interfaces and flows.");
        welcome_description_4.setFontPostscriptName("Helvetica");
        welcome_description_4.setFontSize(36);
        welcome_description_4.setTextAlignment(0);
        welcome_description_4.setTextColor(flowColor);
        welcome_description_4.setTextBehaviour(1);
        var tFrame = welcome_description_4.frame();
        tFrame.setX(200);
        tFrame.setY(1116);
        tFrame.setHeight(129);
        tFrame.setWidth(1000);
        welcome_artboard.addLayer(welcome_description_4);

        // hint
        var hint = MSTextLayer["new"]();
        hint.setName("Hint");
        hint.setStringValue("Create all your designs in the Symbols page\n\nNOTE: Do not change the names of the Symbols");
        hint.setFontPostscriptName("Helvetica");
        hint.setFontSize(48);
        hint.setTextAlignment(2);
        hint.setTextColor(hintColor);
        hint.setTextBehaviour(1);
        var tFrame = hint.frame();
        tFrame.setX(1782);
        tFrame.setY(552);
        tFrame.setHeight(174);
        tFrame.setWidth(386);
        welcome_artboard.addLayer(hint);

        var FillType = { Solid: 0, Gradient: 1, Pattern: 4, Noise: 5 };
        var PatternFillType = { Tile: 0, Fill: 1, Stretch: 2, Fit: 3 };
        var introRect = MSShapeGroup.shapeWithRect({
            origin: { x: 2172, y: 300 },
            size: { width: 1366, height: 1460 }
        });
        var fill = introRect.style().addStylePartOfType(0);
        var image = fetchImage("https://www.reqfire.com/images/furniture/welcome_images.png");

        if (image) {
            fill.fillType = FillType.Pattern;
            fill.patternFillType = PatternFillType.Fit;
            fill.image = MSImageData.alloc().initWithImage(image);
        } else {
            print("Can't load image!");
        }

        welcome_artboard.addLayer(introRect);
        symbolZoom(context, welcome_artboard);
    }

    function getInputFromUser(context) {
        var window = createInputWindow(context);
        var alert = window[0];
        var response = alert.runModal();
        if (response == "1000") {
            jsonInput = jsonTextField.stringValue();
            //save user input to user defaults to enable auto filled text field 
            userDefaults.setObject_forKey(jsonInput, "jsonInput");
            userDefaults.synchronize();
            return true;
        } else {
            return false;
        }
    }

    function createInputWindow(context) {
        userDefaults = NSUserDefaults.alloc().initWithSuiteName("com.bohemiancoding.sketch.exportSelectedInterface");

        var alert = COSAlertWindow["new"]();
        alert.setMessageText("Enter your Reqfire project's API Key");
        alert.addButtonWithTitle("Ok");
        alert.addButtonWithTitle("Cancel");
        var viewWidth = 400;
        var viewHeight = 150;
        var view = NSView.alloc().initWithFrame(NSMakeRect(0, 0, viewWidth, viewHeight));
        alert.addAccessoryView(view);

        var linkLabel = NSTextField.alloc().initWithFrame(NSMakeRect(0, viewHeight - 55, viewWidth - 100, 35));
        linkLabel.setStringValue("This can be found at the Reqfire > Export > Sketch page.");
        linkLabel.setSelectable(false);
        linkLabel.setEditable(false);
        linkLabel.setBezeled(false);
        linkLabel.setDrawsBackground(false);

        var jsonLabel = NSTextField.alloc().initWithFrame(NSMakeRect(0, viewHeight - 85, viewWidth - 100, 20));
        jsonLabel.setStringValue("API Key");
        jsonLabel.setSelectable(false);
        jsonLabel.setEditable(false);
        jsonLabel.setBezeled(false);
        jsonLabel.setDrawsBackground(false);

        view.addSubview(linkLabel);
        view.addSubview(jsonLabel);

        jsonTextField = NSTextField.alloc().initWithFrame(NSMakeRect(0, viewHeight - 105, 300, 20));
        jsonTextField.setStringValue(getJsonValue(context));
        view.addSubview(jsonTextField);

        return [alert];
    }

    function getJsonValue(context) {
        // get value by the key
        var jsonValue = userDefaults.objectForKey("jsonInput");
        if (jsonValue != undefined) {
            return jsonValue;
        } else {
            return ""; // Default value
        }
    }

    function logRequest(key) {
        var request = NSURLRequest.requestWithURL(NSURL.URLWithString("https://www.reqfire.com/app/project/sketchevent/type/0/ext/" + key));
    }

    function getCurrentView(doc) {
        if (doc.currentView) {
            return doc.currentView();
        } else if (doc.contentDrawView) {
            return doc.contentDrawView();
        }

        log("ERROR: Can not get currentView");
        return null;
    }

    // zooming out current page
    function symbolZoom(context, group) {
        var targetRect = group.rect();
        var padding = 0.025;
        targetRect.origin.x -= targetRect.size.width * padding;
        targetRect.origin.y -= targetRect.size.height * padding;
        targetRect.size.width *= 1 + padding * 2;
        targetRect.size.height *= 1 + padding * 2;
        var view = getCurrentView(context.document);
        view.zoomToFitRect(targetRect);
    }
};

/***/ })
/******/ ]);
  if (key === 'default' && typeof exports === 'function') {
    exports(context);
  } else {
    exports[key](context);
  }
}
that['onRun'] = __skpm_run.bind(this, 'default')
