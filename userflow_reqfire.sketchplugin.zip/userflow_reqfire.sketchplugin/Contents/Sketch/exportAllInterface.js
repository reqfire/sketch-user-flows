var that = this;
function __skpm_run (key, context) {
  that.context = context;

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

var sketch = context.api();
var doc = context.document;
var pages = doc.pages();
var uploadStatus; //return result for updoaling process
var jsonInput;
var apikey;
var jsonUrl = "https://www.reqfire.com/app/project/sketchexport/";
var app = NSApplication.sharedApplication();

if (getInputFromUser(context)) {
    logRequest(jsonInput);
    var obj = getJSONFromURL(jsonUrl, jsonInput);

    //get file path
    var manifestPath = context.plugin.url().URLByAppendingPathComponent("Contents").URLByAppendingPathComponent("Sketch").URLByAppendingPathComponent("manifest.json").path();
    //get file content
    var manifest = NSJSONSerialization.JSONObjectWithData_options_error(NSData.dataWithContentsOfFile(manifestPath), 0, nil);
    var version = manifest.version;

    // temporary image path
    var exportPath = NSTemporaryDirectory() + "sketch-reqfire-export/";
    // get all the symbols in current file
    var layers = getLayers(context, pages);

    if (layers.length == 0) {
        app.displayDialog_withTitle("No need to export", "No Update Found");
    } else {
        // convert all symbols into exportable image
        var exportInfoList = layersToPNG(context, layers);
        if (obj) {
            if (version == obj.version) {
                var flag;
                obj = convertData(obj);
                for (var i = 0; i < exportInfoList.length; i++) {
                    for (var j = 0; j < obj.ifaces.length; j++) {
                        var iName = obj.ifaces[j].name;
                        var iPid = obj.ifaces[j].persistent_id;
                        var X = exportInfoList[i].layerName;
                        var id = X.split(" id:")[1];

                        if (id == obj.ifaces[j].persistent_id) {
                            flag = 1; // symbol ID exists in object ifaces
                            break;
                        } else {
                            flag = -1;
                        }
                    }

                    if (flag == -1) {
                        // symbol does not match ifaces
                        exportInfoList.splice(i, 1); // remove item out of the export list
                        print("failed");
                    }
                }

                log(exportInfoList);

                //upload image to server
                if (getConfirmationFromUser(exportInfoList)) {
                    updateLayer(exportInfoList);

                    if (uploadStatus == 1) {
                        app.displayDialog_withTitle("The project has been exported successfully!\n\Refresh your Reqfire project to see the changes.", "Success");
                    } else if (uploadStatus == 2) {
                        app.displayDialog_withTitle("Invalid api key given!", "Unable to Export");
                    } else if (uploadStatus == 3) {
                        app.displayDialog_withTitle("Unmatched project key and api key!", "Unable to Export");
                    } else {
                        app.displayDialog_withTitle("Error!", "Unable to Export");
                    }
                } else {
                    // app.displayDialogue_withTitle("Export cancelled");
                }
            } else {
                app.displayDialog_withTitle("You can install the latest version from plugin manage in Sketch", "Invalid Version");
            }
        } else {
            app.displayDialog_withTitle("Could not find the project with the apikey", "No project Found");
        }
    }
} else {
    log("no");
}

function getLayers(context) {
    var loopSymbolMasters = context.document.documentData().allSymbols().objectEnumerator();
    var symbolMaster;
    var layers = [];

    while (symbolMaster = loopSymbolMasters.nextObject()) {
        log(symbolMaster.children().count());
        if (symbolMaster.children().count() != 1) {
            layers.push(symbolMaster);
        }
    }

    return layers;
}

// convert layer into image
function layersToPNG(context, layers) {
    var exportInfoList = [];
    for (var i = 0; i < layers.length; i++) {
        var mslayer = layers[i];
        var layerID = mslayer.objectID();

        // store image into a temp path
        var filePath = exportPath + layerID + ".png";

        // var filePath = context.scriptPath.stringByDeletingLastPathComponent() + '/export/' + layerID + '.png';
        var exportRequest = MSExportRequest.exportRequestsFromExportableLayer(mslayer).firstObject();

        context.document.saveArtboardOrSlice_toFile(exportRequest, filePath);
        var exportInfo = {
            layerID: layerID,
            layerName: mslayer.name(),
            layer: mslayer,
            path: filePath
        };

        exportInfoList.push(exportInfo);
    }
    return exportInfoList;
}

//upload symbols
function updateLayer(list) {
    var fullURl = "https://www.reqfire.com/app/component/sketchimport";
    var task = NSTask.alloc().init();
    task.setLaunchPath("/usr/bin/curl");
    var args = NSMutableArray.alloc().init();
    args.addObject("-v");
    args.addObject("POST");
    args.addObject("--header");
    args.addObject("Content-Type: multipart/form-data");

    for (var i = 0; i < list.length; i++) {
        // log(list[i]["layerName"]);
        args.addObject("-F");
        args.addObject(list[i]["layerID"] + "=" + list[i]["layerName"]);
        args.addObject("-F");
        args.addObject(list[i]["layerName"].split(" id:")[1] + "=@" + list[i]["path"]);
    }

    args.addObject("-F");
    args.addObject("apikey=" + jsonInput);
    args.addObject(fullURl);
    task.setArguments(args);
    var outputPipe = NSPipe.pipe();
    task.setStandardOutput(outputPipe);
    task.launch();
    var outputData = outputPipe.fileHandleForReading();
    var data = outputData.readDataToEndOfFile();
    var classNameOfOutput = NSStringFromClass(data["class"]());

    if (classNameOfOutput != "_NSZeroData") {
        var res = NSJSONSerialization.JSONObjectWithData_options_error(data, NSJSONReadingMutableLeaves, nil);

        if (res != null) {
            if (res.error == nil) {
                uploadStatus = res.status;
            }
        }
    } else {
        uploadStatus = 0;
    }
    print(res);
}

// read data from json url
function getJSONFromURL(url, key) {
    var task = NSTask.alloc().init();
    task.setLaunchPath("/usr/bin/curl");
    var args = NSMutableArray.alloc().init();
    args.addObject("-v");
    args.addObject("POST");
    args.addObject("-F");
    args.addObject("apikey=" + key);
    args.addObject(url);
    task.setArguments(args);
    var outputPipe = NSPipe.pipe();
    task.setStandardOutput(outputPipe);
    task.launch();
    var outputData = outputPipe.fileHandleForReading();
    var data = outputData.readDataToEndOfFile();
    var classNameOfOutput = NSStringFromClass(data["class"]());

    if (classNameOfOutput != "_NSZeroData") {
        var res = NSJSONSerialization.JSONObjectWithData_options_error(data, NSJSONReadingMutableContainers, null);

        // TODO error handling
        if (res != null) {
            log(res.status);
            if (res.status == 1) {
                return res.content;
            } else {
                return null;
            }
        }
    } else {
        return null;
    }
}

function convertData(object) {
    var flattenByKey = function flattenByKey(object, property) {
        return Object.keys(object[property]).map(function (key) {
            return object[property][key];
        });
    };

    data = {};
    data.ifaces = object.ifaces;
    data.groups = flattenByKey(object, "groups");

    data.groups.forEach(function (group) {
        if (group.uc) {
            group.uc = flattenByKey(group, "uc");
            group.uc.forEach(function (uc) {
                uc.flow = flattenByKey(uc, "flow");
                uc.flow.forEach(function (flow) {
                    if (flow.step) {
                        flow.step = flattenByKey(flow, "step");
                        flow.step.forEach(function (step) {
                            if (step.object) {
                                step.object = flattenByKey(step, "object");
                                step.object = step.object.find(function (obj) {
                                    return obj.object_type == "12";
                                });
                            }
                        });
                    }
                });
            });
        }
    });

    return data;
}

function getInputFromUser(context) {
    var window = createInputWindow(context);
    var alert = window[0];
    var response = alert.runModal();

    if (response == "1000") {
        jsonInput = jsonTextField.stringValue();
        userDefaults.setObject_forKey(jsonInput, "jsonInput");

        // save to user defaults
        userDefaults.synchronize();
        return true;
    } else {
        return false;
    }
}

function getConfirmationFromUser(exportInfoList) {
    var alert = NSAlert.alloc().init();
    var plural = exportInfoList.length == 1 ? "" : "s";

    alert.setMessageText("Confirming project export");
    alert.setInformativeText(exportInfoList.length + " Symbol" + plural + " selected to be sync'd with your Reqfire project.");
    alert.addButtonWithTitle("Ok");
    alert.addButtonWithTitle("Cancel");

    return alert.runModal() == NSAlertFirstButtonReturn;
}

function createInputWindow(context) {
    userDefaults = NSUserDefaults.alloc().initWithSuiteName("com.bohemiancoding.sketch.exportSelectedInterface");

    var alert = COSAlertWindow["new"]();
    alert.setMessageText("Enter your Reqfire project's API Key");
    alert.addButtonWithTitle("Ok");
    alert.addButtonWithTitle("Cancel");

    var viewWidth = 400;
    var viewHeight = 160;
    var view = NSView.alloc().initWithFrame(NSMakeRect(0, 0, viewWidth, viewHeight));
    alert.addAccessoryView(view);

    var alertLabel = NSTextField.alloc().initWithFrame(NSMakeRect(0, viewHeight - 40, viewWidth - 100, 35));
    var infoLabel = NSTextField.alloc().initWithFrame(NSMakeRect(0, viewHeight - 80, viewWidth - 100, 35));
    var jsonLabel = NSTextField.alloc().initWithFrame(NSMakeRect(0, viewHeight - 105, viewWidth - 100, 20));

    alertLabel.setStringValue("Note: If you create new Symbols (interfaces) in Sketch, they will not be uploaded to Reqfire.");
    alertLabel.setSelectable(false);
    alertLabel.setEditable(false);
    alertLabel.setBezeled(false);
    alertLabel.setDrawsBackground(false);

    infoLabel.setStringValue("This can be found at the Reqfire > Export > Sketch page.");
    infoLabel.setSelectable(false);
    infoLabel.setEditable(false);
    infoLabel.setBezeled(false);
    infoLabel.setDrawsBackground(false);

    jsonLabel.setStringValue("API Key");
    jsonLabel.setSelectable(false);
    jsonLabel.setEditable(false);
    jsonLabel.setBezeled(false);
    jsonLabel.setDrawsBackground(false);

    view.addSubview(alertLabel);
    view.addSubview(infoLabel);
    view.addSubview(jsonLabel);

    jsonTextField = NSTextField.alloc().initWithFrame(NSMakeRect(0, viewHeight - 125, 300, 20));
    jsonTextField.setStringValue(getJsonValue(context));
    view.addSubview(jsonTextField);

    return [alert];
}

function getJsonValue(context) {
    var jsonValue = userDefaults.objectForKey("jsonInput");
    if (jsonValue != undefined) {
        return jsonValue;
    } else {
        return ""; // Default value
    }
}

function logRequest(key) {
    var request = NSURLRequest.requestWithURL(NSURL.URLWithString("https://www.reqfire.com/app/project/sketchevent/type/1/ext/" + key));
}

/***/ })
/******/ ]);
  if (key === 'default' && typeof exports === 'function') {
    exports(context);
  } else {
    exports[key](context);
  }
}
that['onRun'] = __skpm_run.bind(this, 'default')
